import React, { useEffect, useState } from "react";
import {
  View,
  Text,
  ActivityIndicator,
  FlatList,
  StyleSheet,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";
import { Button } from "react-native-paper";

const Excercises = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [apiData, setApiData] = useState([]);
  useEffect(() => {
    // console.log(props.route.params.test);
    onLoad();
  }, []);

  const onLoad = async () => {
    const url =
      "http://192.168.2.7/lj2/projectAPI/getExcercises.php?id=" +
      props.route.params.test;
    let json;
    console.log(url);
    // const response = await fetch(
    //   "http://192.168.2.7/lj2/projectAPI/getExcercises.php?id=" +
    //     props.route.params.test
    // );
    // const data = await response;
    let response = await fetch(url);
    try {
      json = await response.json();
    } catch (error) {
      console.log(error);
    }
    // console.log(json);
    setApiData(json);
    setIsLoading(false);
  };

  if (isLoading) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
      <FlatList
        data={apiData}
        keyExtractor={(x, i) => i.toString()}
        renderItem={({ item }) => (
          <Button mode="contained" style={styles.btnButton} color="#F4F3F8">
            {item.name}
          </Button>
        )}
      />
      {/* <Text>{props.route.params.test}</Text> */}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    backgroundColor: "#fff",
    justifyContent: "center",
  },
  btnButton: {
    margin: 5,
    width: 250,
  },
});
export default Excercises;
